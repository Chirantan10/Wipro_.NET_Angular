import { Directive, ElementRef, Input, OnChanges, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective implements OnChanges {
  @Input('appHighlight') price: number | undefined;
  constructor(private el: ElementRef, private renderer: Renderer2) {}

  ngOnChanges() {
    const threshold = 2000;
    if (this.price != null && this.price > threshold) {
      this.renderer.setStyle(this.el.nativeElement, 'background', 'linear-gradient(90deg, #fff9e6, #fff6d1)');
    } else {
      this.renderer.removeStyle(this.el.nativeElement, 'background');
    }
  }
}
