# Event Management App (Angular)

## Description
A simple Angular demo app that lists upcoming events, formats ticket prices using a custom pipe, and highlights premium events using a custom directive.

## Setup
1. Ensure you have Node.js and Angular CLI installed.
2. Run `npm install` to install dependencies.
3. Run `ng serve` to start the dev server and open `http://localhost:4200`.

## Features
- EventListComponent: displays events using *ngFor.
- PriceFormatPipe: formats numbers to INR currency (e.g., 3500 -> ₹3,500.00).
- HighlightDirective: applies a light-gold background for events with price > ₹2000.
- Simple animation via CSS transitions.

