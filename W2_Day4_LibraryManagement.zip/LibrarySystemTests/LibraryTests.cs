using NUnit.Framework;
using LibrarySystem;
using System.Linq;

namespace LibrarySystemTests
{
    public class Tests
    {
        private Library library;

        [SetUp]
        public void Setup()
        {
            library = new Library();
        }

        [Test]
        public void TestAddBook()
        {
            var book = new Book("Book Title", "Author", "1234");
            library.AddBook(book);
            Assert.AreEqual(1, library.Books.Count);
        }

        [Test]
        public void TestRegisterBorrower()
        {
            var borrower = new Borrower("John Doe", "CARD001");
            library.RegisterBorrower(borrower);
            Assert.AreEqual(1, library.Borrowers.Count);
        }

        [Test]
        public void TestBorrowBook()
        {
            var book = new Book("Book", "Author", "1234");
            var borrower = new Borrower("John", "CARD001");
            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("1234", "CARD001");
            Assert.IsTrue(book.IsBorrowed);
            Assert.Contains(book, borrower.BorrowedBooks);
        }

        [Test]
        public void TestReturnBook()
        {
            var book = new Book("Book", "Author", "1234");
            var borrower = new Borrower("John", "CARD001");
            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("1234", "CARD001");
            library.ReturnBook("1234", "CARD001");
            Assert.IsFalse(book.IsBorrowed);
            Assert.IsFalse(borrower.BorrowedBooks.Contains(book));
        }

        [Test]
        public void TestViewBooksAndBorrowers()
        {
            var book = new Book("Book", "Author", "1234");
            var borrower = new Borrower("John", "CARD001");
            library.AddBook(book);
            library.RegisterBorrower(borrower);
            Assert.AreEqual(1, library.ViewBooks().Count);
            Assert.AreEqual(1, library.ViewBorrowers().Count);
        }
    }
}
