# Book Management REST API

## Setup
```bash
npm install
npm start
```

## API Endpoints
- GET `/` - Welcome message
- GET `/books` - Get all books
- GET `/books/:id` - Get a book by ID
- POST `/books` - Add a book
- PUT `/books/:id` - Update a book
- DELETE `/books/:id` - Delete a book
```

