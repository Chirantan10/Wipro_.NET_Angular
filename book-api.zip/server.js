const express = require('express');
const { v4: uuidv4 } = require('uuid');
const bookService = require('./services/bookService');

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
    res.json({ message: 'Welcome to Book Management API' });
});

app.get('/books', async (req, res) => {
    const books = await bookService.getAllBooks();
    res.json(books);
});

app.get('/books/:id', async (req, res) => {
    const book = await bookService.getBookById(req.params.id);
    if (book) res.json(book);
    else res.status(404).json({ message: 'Book not found' });
});

app.post('/books', async (req, res) => {
    const { title, author } = req.body;
    if (!title || !author) {
        return res.status(400).json({ message: 'Title and author are required' });
    }
    const newBook = { id: uuidv4(), title, author };
    await bookService.addBook(newBook);
    res.status(201).json(newBook);
});

app.put('/books/:id', async (req, res) => {
    const updatedBook = await bookService.updateBook(req.params.id, req.body);
    if (updatedBook) res.json(updatedBook);
    else res.status(404).json({ message: 'Book not found' });
});

app.delete('/books/:id', async (req, res) => {
    await bookService.deleteBook(req.params.id);
    res.status(204).end();
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
