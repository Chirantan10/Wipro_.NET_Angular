const fs = require('fs').promises;
const path = require('path');
const EventEmitter = require('events');

const filePath = path.join(__dirname, '../data/books.json');
const bookEvents = new EventEmitter();

async function readBooks() {
    try {
        const data = await fs.readFile(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading books:', error);
        return [];
    }
}

async function writeBooks(books) {
    try {
        await fs.writeFile(filePath, JSON.stringify(books, null, 2));
    } catch (error) {
        console.error('Error writing books:', error);
    }
}

async function getAllBooks() {
    return await readBooks();
}

async function getBookById(id) {
    const books = await readBooks();
    return books.find(book => book.id === id);
}

async function addBook(book) {
    const books = await readBooks();
    books.push(book);
    await writeBooks(books);
    bookEvents.emit('bookAdded', book);
}

async function updateBook(id, updatedBook) {
    const books = await readBooks();
    const index = books.findIndex(book => book.id === id);
    if (index !== -1) {
        books[index] = { ...books[index], ...updatedBook };
        await writeBooks(books);
        bookEvents.emit('bookUpdated', books[index]);
        return books[index];
    }
    return null;
}

async function deleteBook(id) {
    let books = await readBooks();
    const book = books.find(book => book.id === id);
    books = books.filter(book => book.id !== id);
    await writeBooks(books);
    if (book) {
        bookEvents.emit('bookDeleted', book);
    }
}

bookEvents.on('bookAdded', (book) => console.log(`Book Added: ${book.title}`));
bookEvents.on('bookUpdated', (book) => console.log(`Book Updated: ${book.title}`));
bookEvents.on('bookDeleted', (book) => console.log(`Book Deleted: ${book.title}`));

module.exports = {
    getAllBooks,
    getBookById,
    addBook,
    updateBook,
    deleteBook
};
