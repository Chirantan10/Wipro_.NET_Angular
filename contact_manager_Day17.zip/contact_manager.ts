
interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

class ContactManager {
    private contacts: Contact[] = [];

    addContact(contact: Contact): void {
        if (this.contacts.find(c => c.id === contact.id)) {
            console.log(`Error: Contact with ID ${contact.id} already exists.`);
            return;
        }
        this.contacts.push(contact);
        console.log(`Contact with ID ${contact.id} added successfully.`);
    }

    viewContacts(): Contact[] {
        return this.contacts;
    }

    modifyContact(id: number, updatedContact: Partial<Contact>): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.log(`Error: Contact with ID ${id} does not exist.`);
            return;
        }
        this.contacts[contactIndex] = { ...this.contacts[contactIndex], ...updatedContact };
        console.log(`Contact with ID ${id} modified successfully.`);
    }

    deleteContact(id: number): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.log(`Error: Contact with ID ${id} does not exist.`);
            return;
        }
        this.contacts.splice(contactIndex, 1);
        console.log(`Contact with ID ${id} deleted successfully.`);
    }
}

// Testing script
const manager = new ContactManager();

manager.addContact({ id: 1, name: "John Doe", email: "john@example.com", phone: "1234567890" });
manager.addContact({ id: 2, name: "Jane Smith", email: "jane@example.com", phone: "0987654321" });

console.log("Contacts:", manager.viewContacts());

manager.modifyContact(1, { phone: "1112223333" });
manager.deleteContact(2);

console.log("Contacts after modifications:", manager.viewContacts());
