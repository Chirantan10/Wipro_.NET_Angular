using NUnit.Framework;
using CalculatorLibrary;
using System;

namespace CalculatorTests
{
    public class Tests
    {
        private Calculator calculator;

        [SetUp]
        public void Setup()
        {
            calculator = new Calculator();
        }

        [Test]
        public void TestAddition()
        {
            Assert.AreEqual(10, calculator.Add(7, 3));
            Assert.AreEqual(0, calculator.Add(0, 0));
        }

        [Test]
        public void TestSubtraction()
        {
            Assert.AreEqual(4, calculator.Subtract(7, 3));
            Assert.AreEqual(0, calculator.Subtract(5, 5));
        }

        [Test]
        public void TestMultiplication()
        {
            Assert.AreEqual(21, calculator.Multiply(7, 3));
            Assert.AreEqual(0, calculator.Multiply(5, 0));
        }

        [Test]
        public void TestDivision()
        {
            Assert.AreEqual(2, calculator.Divide(6, 3));
        }

        [Test]
        public void TestDivisionByZero()
        {
            Assert.Throws<DivideByZeroException>(() => calculator.Divide(5, 0));
        }
    }
}
