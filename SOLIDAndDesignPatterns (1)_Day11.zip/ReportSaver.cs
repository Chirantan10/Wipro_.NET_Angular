
using System.IO;

public class ReportSaver
{
    public void SaveReport(string content, string filePath)
    {
        File.WriteAllText(filePath, content);
    }
}
