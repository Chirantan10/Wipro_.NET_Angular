
using System;
using System.Collections.Generic;

public interface IObserver
{
    void Update(string weatherData);
}

public class WeatherStation
{
    private readonly List<IObserver> _observers = new();

    public void Register(IObserver observer) => _observers.Add(observer);
    public void Unregister(IObserver observer) => _observers.Remove(observer);

    public void Notify(string weatherData)
    {
        foreach (var observer in _observers)
        {
            observer.Update(weatherData);
        }
    }
}

public class WeatherDisplay : IObserver
{
    public void Update(string weatherData)
    {
        Console.WriteLine($"Weather Updated: {weatherData}");
    }
}
