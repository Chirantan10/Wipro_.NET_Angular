
public interface IDocument
{
    string GetContent();
}

public class PDFDocument : IDocument
{
    public string GetContent() => "PDF Content";
}

public class WordDocument : IDocument
{
    public string GetContent() => "Word Content";
}

public class DocumentFactory
{
    public static IDocument CreateDocument(string type)
    {
        return type switch
        {
            "PDF" => new PDFDocument(),
            "Word" => new WordDocument(),
            _ => throw new ArgumentException("Unknown document type")
        };
    }
}
