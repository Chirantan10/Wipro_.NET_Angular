
public interface IPrintable
{
    void Print();
}

public interface ISavable
{
    void Save();
}
