
public abstract class Report
{
    public abstract string Generate();
}
