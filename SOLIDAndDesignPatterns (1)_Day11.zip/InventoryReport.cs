
public class InventoryReport : Report
{
    public override string Generate()
    {
        return "Inventory Report";
    }
}
