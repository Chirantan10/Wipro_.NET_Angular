
public interface IReportService
{
    void ProcessReport();
}

public class ReportService : IReportService
{
    private readonly ReportGenerator _generator;
    private readonly ReportSaver _saver;

    public ReportService(ReportGenerator generator, ReportSaver saver)
    {
        _generator = generator;
        _saver = saver;
    }

    public void ProcessReport()
    {
        var content = _generator.GenerateReport();
        _saver.SaveReport(content, "report.txt");
    }
}
