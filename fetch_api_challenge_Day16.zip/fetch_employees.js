
// Task 1: Fetch and display employee data in console
fetch("https://dummy.restapiexample.com/api/v1/employees")
    .then(response => response.json())
    .then(data => {
        console.log("Employee Data:", data);
    })
    .catch(error => console.error("Error fetching employee data:", error));
