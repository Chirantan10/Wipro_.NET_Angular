using Microsoft.AspNetCore.Mvc;
using BookstoreApp.Data;
using BookstoreApp.Models;

namespace BookstoreApp.Controllers
{
    public class BookController : Controller
    {
        private readonly BookRepository _repository;

        public BookController(IConfiguration config)
        {
            _repository = new BookRepository(config);
        }

        public IActionResult Index()
        {
            var books = _repository.GetBooks();
            return View(books);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _repository.AddBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var book = _repository.GetBooks().FirstOrDefault(b => b.Id == id);
            return View(book);
        }

        [HttpPost]
        public IActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                _repository.UpdateBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }

        public IActionResult Delete(int id)
        {
            _repository.DeleteBook(id);
            return RedirectToAction("Index");
        }
    }
}