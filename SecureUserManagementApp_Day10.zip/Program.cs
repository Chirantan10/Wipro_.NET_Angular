
using System;
using Serilog;

class Program
{
    static void Main()
    {
        LoggerService.Init();

        try
        {
            var user = new User();
            user.Register("john", "secret123");
            Console.WriteLine("User registered.");

            bool success = user.Authenticate("secret123");
            Console.WriteLine(success ? "Authentication successful." : "Authentication failed.");

            var encryptionService = new EncryptionService();
            string encrypted = encryptionService.Encrypt("Sensitive Info");
            Console.WriteLine($"Encrypted: {encrypted}");
            string decrypted = encryptionService.Decrypt(encrypted);
            Console.WriteLine($"Decrypted: {decrypted}");

            LoggerService.LogInfo("Application ran successfully.");
        }
        catch (Exception ex)
        {
            LoggerService.LogError(ex);
            Console.WriteLine("An error occurred.");
        }
    }
}
