
using Serilog;
using System;

public class LoggerService
{
    public static void Init()
    {
        Log.Logger = new LoggerConfiguration()
            .WriteTo.File("log.txt", rollingInterval: RollingInterval.Day)
            .CreateLogger();
    }

    public static void LogInfo(string message) => Log.Information(message);
    public static void LogError(Exception ex) => Log.Error(ex, "An error occurred");
}
