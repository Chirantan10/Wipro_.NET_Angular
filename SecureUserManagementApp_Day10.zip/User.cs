
using System.Security.Cryptography;
using System.Text;

public class User
{
    public string Username { get; set; }
    public string HashedPassword { get; private set; }

    public void Register(string username, string password)
    {
        Username = username;
        HashedPassword = HashPassword(password);
    }

    public bool Authenticate(string password)
    {
        return HashedPassword == HashPassword(password);
    }

    private string HashPassword(string password)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }
    }
}
