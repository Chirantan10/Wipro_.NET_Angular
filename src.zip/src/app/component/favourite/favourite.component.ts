import { Component } from '@angular/core';

@Component({
  selector: 'app-favourite',
  standalone: false,
  templateUrl: './favourite.component.html',
  styleUrl: './favourite.component.css'
})
export class FavouriteComponent {

}
