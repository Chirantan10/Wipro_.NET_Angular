import { ReversepipePipe } from './reversepipe.pipe';

describe('ReversepipePipe', () => {
  it('create an instance', () => {
    const pipe = new ReversepipePipe();
    expect(pipe).toBeTruthy();
  });
});
